var randomnum1 = Math.floor(Math.random()*6)+1;
randomimage1 = "images/dice"+randomnum1+".png"
var randomnum2 = Math.floor(Math.random()*6)+1;
randomimage2 = "images/dice"+randomnum2+".png"

var image1 = document.querySelectorAll("img")[0];
image1.setAttribute("src", randomimage1);

var image2 = document.querySelectorAll("img")[1];
image2.setAttribute("src", randomimage2);

if(randomnum1>randomnum2)
{
    document.querySelector("h1").innerText="Player 1 won!";
}
else if(randomnum2>randomnum1)
    {
        document.querySelector("h1").innerText="Player 2 won!";
    }

    else
    {
        document.querySelector("h1").innerText="Draw!";
    }
